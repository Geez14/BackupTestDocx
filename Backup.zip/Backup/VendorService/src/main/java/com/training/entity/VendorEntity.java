package com.training.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.*;

@Entity
@Table(name = "vendor")
@Getter
@Setter
@ToString
public class VendorEntity {

	@Id
	@Column(name = "vendor_id")
	private String vendorId;
	@Column(name = "vendor_name")
	private String vendorName;
	@Column(name = "vendor_address")
	private String vendorAddress;
	@Column(name = "contact_person")
	private String contactPerson;
	@Column(name = "contact_number")
	private String contactNumber;

	public VendorEntity() {
		super();
	}
}
