package com.training.business.bean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;


@Getter
@Setter
@ToString
@AllArgsConstructor
public class VendorBean implements Serializable {
	private String vendorId;
	private String vendorName;
	private String vendorAddress;
	private String contactPerson;
	private String contactNumber;

	public VendorBean() {
		super();
	}
}
