package com.training.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.business.bean.VendorBean;
import com.training.dao.VendorDAO;
import com.training.entity.VendorEntity;

@Service
public class VendorServiceImpl implements VendorService {

	private final VendorDAO vendorDAO;

	@Autowired
	public VendorServiceImpl(VendorDAO vendorDAO) {
		this.vendorDAO = vendorDAO;
	}

	@Override
	public List<VendorBean> getVendorDetails() {

		List<VendorEntity> vendorEntities = vendorDAO.findAll();
		return vendorEntities.stream().map(VendorServiceImpl::convertEntityToBean).toList();
	}

	private static VendorBean convertEntityToBean(VendorEntity vendorEntity) {
		VendorBean vendorBean = new VendorBean();
		vendorBean.setVendorId(vendorEntity.getVendorId());
		vendorBean.setVendorName(vendorEntity.getVendorName());
		vendorBean.setVendorAddress(vendorEntity.getVendorAddress());
		vendorBean.setContactPerson(vendorEntity.getContactPerson());
		vendorBean.setContactNumber(vendorEntity.getContactNumber());

		return vendorBean;
	}
}
