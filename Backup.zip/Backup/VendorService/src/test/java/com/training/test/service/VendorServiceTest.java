package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.service.VendorService;

@SpringBootTest
class VendorServiceTest {

	/*
	 * Autowire the VendorService object below
	 * 
	 */
	@Autowired
	private VendorService vendorService;

	/*
	 * Method - notNullVendorServiceTest()
	 * Assert only that VendorService object is Not null
	 * 
	 */

	@Test
	void notNullVendorServiceTest() {
		assertNotNull(vendorService);
	}

	/*
	 * Method - notNullGetVendorDetailsTest()
	 * Assert only that VendorService getVendorDetails is not returning a null value
	 * 
	 */

	@Test
	void notNullGetVendorDetailsTest() {
		assertNotNull(vendorService.getVendorDetails());
	}

	/*
	 * Method - countGetVendorDetailsTest()
	 * Assert only that VendorService getVendorDetails list size matches to 5
	 * 
	 */

	@Test
	void countGetVendorDetailsTest() {
		assertEquals(5, vendorService.getVendorDetails().size());
	}

	/*
	 * Method - recordGetVendorDetailsTest()
	 * Assert only that VendorService getVendorDetails first bean name matches --> "Only Vimal"
	 * 
	 */
		
	@Test
	void recordGetVendorDetailsTest() {
		assertEquals("Only Vimal", vendorService.getVendorDetails().get(0).getVendorName());
	}

}