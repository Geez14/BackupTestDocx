package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendorServiceApplicationTests {

	Logger logger = LoggerFactory.getLogger(VendorServiceApplicationTests.class);

	@Test
	void contextLoads() {
		logger.info("UNIT TEST STARTED");
		String actual = "Spring Boot";
		assertEquals("Spring Boot", actual, "String does not match");
	}

}
