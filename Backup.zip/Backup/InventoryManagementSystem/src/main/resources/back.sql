DROP DATABASE IF EXISTS dbpurchase;
CREATE DATABASE dbpurchase;
USE dbpurchase;

DROP TABLE IF EXISTS purchase;
CREATE TABLE IF NOT EXISTS purchase (
  purchase_id int(11) unsigned NOT NULL AUTO_INCREMENT,
  brandname varchar(255) DEFAULT NULL,
  material_category_id varchar(255) DEFAULT NULL,
  material_type_id varchar(255) DEFAULT NULL,
  purchase_amount double DEFAULT NULL,
  purchase_date date DEFAULT NULL,
  quantity int(11) DEFAULT NULL,
  status varchar(255) DEFAULT NULL,
  transaction_id varchar(255) DEFAULT NULL,
  unit_id varchar(255) DEFAULT NULL,
  vendor_name varchar(255) DEFAULT NULL,
  PRIMARY KEY  (purchase_id)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;