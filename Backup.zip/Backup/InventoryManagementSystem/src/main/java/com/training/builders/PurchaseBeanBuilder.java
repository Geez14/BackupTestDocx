package com.training.builders;

import java.util.Date;

import com.training.business.bean.PurchaseBean;

public class PurchaseBeanBuilder {
    private Integer purchaseId;
    private String transactionId;
    private String vendorName;
    private String materialCategoryId;
    private String materialTypeId;
    private String brandName;
    private String unitId;
    private Integer quantity;
    private Double purchaseAmount;
    private Date purchaseDate;
    private Double balance;
    private String materialCategoryName;
    private String materialTypeName;
    private String materialUnitName;
    private String status;

    public PurchaseBeanBuilder setPurchaseId(Integer purchaseId) {
        this.purchaseId = purchaseId;
        return this;
    }

    public PurchaseBeanBuilder setTransactionId(String transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    public PurchaseBeanBuilder setVendorName(String vendorName) {
        this.vendorName = vendorName;
        return this;
    }

    public PurchaseBeanBuilder setMaterialCategoryId(String materialCategoryId) {
        this.materialCategoryId = materialCategoryId;
        return this;
    }

    public PurchaseBeanBuilder setMaterialTypeId(String materialTypeId) {
        this.materialTypeId = materialTypeId;
        return this;
    }

    public PurchaseBeanBuilder setBrandName(String brandName) {
        this.brandName = brandName;
        return this;
    }

    public PurchaseBeanBuilder setUnitId(String unitId) {
        this.unitId = unitId;
        return this;
    }

    public PurchaseBeanBuilder setQuantity(Integer quantity) {
        this.quantity = quantity;
        return this;
    }

    public PurchaseBeanBuilder setPurchaseAmount(Double purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
        return this;
    }

    public PurchaseBeanBuilder setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
        return this;
    }

    public PurchaseBeanBuilder setStatus(String status) {
        this.status = status;
        return this;
    }

    public PurchaseBeanBuilder setBalance(Double balance) {
        this.balance = balance;
        return this;
    }

    public PurchaseBeanBuilder setMaterialCategoryName(String materialCategoryName) {
        this.materialCategoryName = materialCategoryName;
        return this;
    }

    public PurchaseBeanBuilder setMaterialTypeName(String materialTypeName) {
        this.materialTypeName = materialTypeName;
        return this;
    }

    public PurchaseBeanBuilder setMaterialUnitName(String materialUnitName) {
        this.materialUnitName = materialUnitName;
        return this;
    }

    public PurchaseBean build() {
        PurchaseBean purchaseBean = new PurchaseBean();
        purchaseBean.setPurchaseId(purchaseId);
        purchaseBean.setTransactionId(transactionId);
        purchaseBean.setVendorName(vendorName);
        purchaseBean.setMaterialCategoryId(materialCategoryId);
        purchaseBean.setMaterialTypeId(materialTypeId);
        purchaseBean.setBrandName(brandName);
        purchaseBean.setUnitId(unitId);
        purchaseBean.setQuantity(quantity);
        purchaseBean.setPurchaseAmount(purchaseAmount);
        purchaseBean.setPurchaseDate(purchaseDate);
        purchaseBean.setStatus(status);
        purchaseBean.setBalance(balance);
        purchaseBean.setMaterialCategoryName(materialCategoryName);
        purchaseBean.setMaterialTypeName(materialTypeName);
        purchaseBean.setMaterialUnitName(materialUnitName);
        return purchaseBean;
    }
}