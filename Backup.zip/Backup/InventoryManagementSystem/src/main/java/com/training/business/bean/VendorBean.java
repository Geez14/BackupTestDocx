package com.training.business.bean;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class VendorBean {

	private String vendorId;
	private String vendorName;
	private String vendorAddress;
	private String contactPerson;
	private String contactNumber;
}