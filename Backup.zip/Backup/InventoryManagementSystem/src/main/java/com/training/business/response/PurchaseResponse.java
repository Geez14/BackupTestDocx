package com.training.business.response;

import com.training.business.bean.PurchaseBean;
import lombok.*;

// Response wrapper for add purchase API: sends operation status, message, and saved purchase.
@Getter
@AllArgsConstructor
public class PurchaseResponse {
	private String status;
	private String message;
	private PurchaseBean purchase;
}
