package com.training.business.bean;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UnitBean {

	private String unitId;
	private String unitName;
}