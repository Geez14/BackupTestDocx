package com.training.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.*;
/*
 *Declare fields to set or get purchaseid, transactionId, vendor name,material category id,material type id,
 *brand name, unit id,quantity,purchase amount, purchase date and status.
 *Generate toString method. Add default and parameterized constructors.
 */

@Entity
@Table(name = "purchase")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class PurchaseEntity {
	@Id
	@Column(name = "purchase_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer purchaseId;
	@Column(name = "transaction_id")
	private String transactionId;
	@Column(name = "vendor_name")
	private String vendorName;
	@Column(name = "material_category_id")
	private String materialCategoryId;
	@Column(name = "material_type_id")
	private String materialTypeId;
	@Column(name = "brandname")
	private String brandName;
	@Column(name = "unit_id")
	private String unitId;
	@Column(name = "quantity")
	private int quantity;
	@Column(name = "purchase_amount")
	private double purchaseAmount;

	@Temporal(TemporalType.DATE)
	@Column(name = "purchase_date")
	private Date purchaseDate;

	@Column(name = "status")
	private String status;
}
