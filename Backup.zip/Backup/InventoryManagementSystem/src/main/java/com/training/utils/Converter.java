package com.training.utils;

import com.training.business.bean.PurchaseBean;
import com.training.entity.PurchaseEntity;

public class Converter {
    private Converter() {
    }

    public static PurchaseBean convertPurchaseEntityToPurchaseBean(PurchaseEntity entity) {
        PurchaseBean bean = new PurchaseBean();
        bean.setPurchaseId(entity.getPurchaseId());
        bean.setTransactionId(entity.getTransactionId());
        bean.setVendorName(entity.getVendorName());
        bean.setMaterialCategoryId(entity.getMaterialCategoryId());
        bean.setMaterialTypeId(entity.getMaterialTypeId());
        bean.setBrandName(entity.getBrandName());
        bean.setUnitId(entity.getUnitId());
        bean.setQuantity(entity.getQuantity());
        bean.setPurchaseAmount(entity.getPurchaseAmount());
        bean.setPurchaseDate(entity.getPurchaseDate());
        bean.setStatus(entity.getStatus());
        return bean;
    }

    public static PurchaseEntity convertPurchaseBeanToPurchaseEntity(PurchaseBean bean) {
        PurchaseEntity entity = new PurchaseEntity();
        entity.setPurchaseId(bean.getPurchaseId());
        entity.setTransactionId(bean.getTransactionId());
        entity.setVendorName(bean.getVendorName());
        entity.setMaterialCategoryId(bean.getMaterialCategoryId());
        entity.setMaterialTypeId(bean.getMaterialTypeId());
        entity.setBrandName(bean.getBrandName());
        entity.setUnitId(bean.getUnitId());
        entity.setQuantity(bean.getQuantity());
        entity.setPurchaseAmount(bean.getPurchaseAmount());
        entity.setPurchaseDate(bean.getPurchaseDate());
        entity.setStatus(bean.getStatus());
        return entity;
    }
}
