package com.training.business.response;

import java.util.List;

import com.training.business.bean.MaterialTypeBean;
import com.training.business.bean.UnitBean;
import lombok.*;

// Response wrapper for dependent dropdown API: sends unit list + material type list together.
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UnitAndTypeResponse {
	private List<UnitBean> unitList;
	private List<MaterialTypeBean> materialTypeList;
}
