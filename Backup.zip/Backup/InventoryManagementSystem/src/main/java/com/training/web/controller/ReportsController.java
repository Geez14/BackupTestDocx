package com.training.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.training.business.bean.PurchaseBean;
import com.training.business.bean.VendorWisePurchaseReportBean;
import com.training.service.ReportsService;


/**
 * <br/>
 * CLASS DESCRIPTION: <br/>
 * A controller class for handling the request coming from
 * DateWisePurchaseReport.jsp
 *
 */
@Controller
@CrossOrigin(origins = "http://localhost:3000")
public class ReportsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsController.class);

	private final ReportsService reportsService;

	@Autowired
	public ReportsController(ReportsService reportsService) {
		this.reportsService = reportsService;
	}

	/**
	 * Material Category Service Consumer is used to fetch the material category name for a given material category id.
	 * Unit Service Consumer is used to fetch the unit name for a given unit id.
	 * Material Type Consumer is used to fetch the material type name for a given material type id.
	 * Vendor Service Consumer is used to fetch the vendor name for a given vendor id.
	 */

	List <PurchaseBean> purchaseIdList;

	/**
	 * METHOD DESCRIPTION: <br/>
	 * This method is used to fetch the purchase details for a given vendor and
	 * between the two given dates 
	 *  
	 * @param vendorWisePurchaseReportBean
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "report/controller/getPurchaseDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<PurchaseBean>> getPurchaseDetails(@RequestBody VendorWisePurchaseReportBean bean)
	{
		LOGGER.info("Execution Started [getPurchaseDetails]");
		List<PurchaseBean> reportList = reportsService.getVendorWisePurchaseDetails(bean.getFromDate(), bean.getToDate(),
				bean.getVendorName());
		LOGGER.info("Execution Over [getPurchaseDetails]");
		return ResponseEntity.ok(reportList);
	}
		
	
}