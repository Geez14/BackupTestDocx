package com.training.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.training.business.bean.PurchaseBean;
import com.training.entity.PurchaseEntity;

import com.training.utils.Converter;

@Repository
public class ReportsDataAccess {
	private final ReportsDAO reportsDAO;

	@Autowired
	public ReportsDataAccess(ReportsDAO reportsDAO) {
		this.reportsDAO = reportsDAO;
	}

	public List<PurchaseBean> getVendorWisePurchaseDetails(Date from, Date to, String vendorName) {
		List<PurchaseEntity> purchaseEntities = reportsDAO.getVendorWisePurchaseDetails(from, to, vendorName);
		return purchaseEntities.stream()
				.map(Converter::convertPurchaseEntityToPurchaseBean)
				.collect(Collectors.toList());
	}
}