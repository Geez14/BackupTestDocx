package com.training.business.bean;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MaterialCategoryBean {

	private String categoryId;
	private String categoryName;
}
