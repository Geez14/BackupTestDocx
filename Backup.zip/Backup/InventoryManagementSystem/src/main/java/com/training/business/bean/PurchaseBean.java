package com.training.business.bean;

import java.util.Calendar;
import java.util.Date;
import java.io.Serializable;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

import com.training.builders.PurchaseBeanBuilder;
import lombok.*;

/*
 *Declare fields to set or get purchaseid, transactionId, vendor name,material category id,material type id,
 *brand name, unit id,quantity,purchase amount, balance, purchase date (should be in dd-MM-yyyy format and should be past date),
 material category name,
	material type name,material unit name and status.
 *Generate toString method. Add default and parameterized constructors.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PurchaseBean implements Serializable {

	private Integer purchaseId;
	private String transactionId;
	@NotBlank(message = "Vendor name is mandatory.")
	private String vendorName;
	@NotBlank(message = "Material category is mandatory.")
	private String materialCategoryId;
	@NotBlank(message = "Material type is mandatory.")
	private String materialTypeId;
	@NotBlank(message = "Brand name is mandatory.")
	private String brandName;
	@NotBlank(message = "Unit ID is mandatory.")
	private String unitId;
	@NotNull(message = "Quantity is mandatory.")
	private Integer quantity;
	@NotNull(message = "Purchase amount is mandatory.")
	private Double purchaseAmount;
	private Double balance;
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date purchaseDate;
	private String materialCategoryName;
	private String materialTypeName;
	private String materialUnitName;
	private String status;

	@AssertTrue(message = "Purchase date must be before today.")
	public boolean isPurchaseDateBeforeToday() {
		if (purchaseDate == null) {
			return true;
		}

		Calendar today = Calendar.getInstance();
		today.set(Calendar.HOUR_OF_DAY, 0);
		today.set(Calendar.MINUTE, 0);
		today.set(Calendar.SECOND, 0);
		today.set(Calendar.MILLISECOND, 0);

		return purchaseDate.before(today.getTime());
	}

	public static PurchaseBeanBuilder builder() {
		return new PurchaseBeanBuilder();
	}
}
