package com.training.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.training.business.bean.PurchaseBean;
import com.training.entity.PurchaseEntity;
import com.training.utils.Converter;

@Repository
public class PurchaseDataAccess {

	private final PurchaseDAO purchaseDAO;

	@Autowired
	public PurchaseDataAccess(PurchaseDAO purchaseDAO) {
		this.purchaseDAO = purchaseDAO;
	}

	public PurchaseBean savePurchaseDetail(PurchaseBean purchaseBean) {
		PurchaseEntity purchaseEntity = Converter.convertPurchaseBeanToPurchaseEntity(purchaseBean);
		PurchaseEntity savedPurchaseEntity = purchaseDAO.save(purchaseEntity);
		PurchaseBean savedPurchaseBean = Converter.convertPurchaseEntityToPurchaseBean(savedPurchaseEntity);
		savedPurchaseBean.setMaterialCategoryName(purchaseBean.getMaterialCategoryName());
		savedPurchaseBean.setMaterialTypeName(purchaseBean.getMaterialTypeName());
		savedPurchaseBean.setMaterialUnitName(purchaseBean.getMaterialUnitName());
		return savedPurchaseBean;
	}
}