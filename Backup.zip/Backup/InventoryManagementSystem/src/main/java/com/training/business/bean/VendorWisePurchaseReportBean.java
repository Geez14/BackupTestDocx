package com.training.business.bean;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.*;

/*
 *Declare fields to set or get from date, to date and vendor name.
  Validate the fields using spring validation annotations.
 *Generate toString method. Add default and parameterized constructors.
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class VendorWisePurchaseReportBean {

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fromDate;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date toDate;
	@NotBlank
	private String vendorName;
}
