package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.PurchaseDAO;
import com.training.dao.PurchaseDataAccess;
import com.training.entity.PurchaseEntity;

@ExtendWith(MockitoExtension.class)
class PurchaseDAOTest {

	@Mock
	private PurchaseDAO purchaseDAO;

	@InjectMocks
	private PurchaseDataAccess purchaseDataAccess;

	@Test
	void testSavePurchaseDetail() {
		PurchaseBean bean = PurchaseBean.builder()
				.setTransactionId("P_ONL_01012026_C01")
				.setVendorName("Only Vimal")
				.setMaterialCategoryId("C001")
				.setMaterialTypeId("T001")
				.setBrandName("BrandX")
				.setUnitId("U001")
				.setQuantity(5)
				.setPurchaseAmount(500.0)
				.setPurchaseDate(new Date())
				.setStatus("SUCCESS")
				.build();
		when(purchaseDAO.save(any(PurchaseEntity.class))).thenAnswer(invocation -> {
			PurchaseEntity entity = invocation.getArgument(0);
			entity.setPurchaseId(101);
			return entity;
		});

		PurchaseBean saved = purchaseDataAccess.savePurchaseDetail(bean);
		assertNotNull(saved);
		assertEquals(101, saved.getPurchaseId());
		assertEquals("SUCCESS", saved.getStatus());
		assertEquals("Only Vimal", saved.getVendorName());
	}

}
