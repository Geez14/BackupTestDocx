DROP TABLE IF EXISTS unit;
DROP TABLE IF EXISTS material_type;
DROP TABLE IF EXISTS material_category;

CREATE TABLE material_category (
    category_id VARCHAR(255) NOT NULL,
    category_name VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE material_type (
    type_id VARCHAR(255) NOT NULL,
    type_name VARCHAR(255) DEFAULT NULL,
    category_id VARCHAR(255) DEFAULT NULL,

    PRIMARY KEY (type_id),
    KEY idx_material_type_category_id (category_id),

    CONSTRAINT fk_material_type_category
        FOREIGN KEY (category_id)
        REFERENCES material_category (category_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE unit (
    unit_id VARCHAR(255) NOT NULL,
    unit_name VARCHAR(255) DEFAULT NULL,
    category_id VARCHAR(255) DEFAULT NULL,

    PRIMARY KEY (unit_id),
    KEY idx_unit_category_id (category_id),

    CONSTRAINT fk_unit_category
        FOREIGN KEY (category_id)
        REFERENCES material_category (category_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
