package com.training.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.business.bean.MaterialCategoryBean;
import com.training.dao.MaterialCategoryDAO;
import com.training.entity.MaterialCategoryEntity;

@Service
public class MaterialServiceImpl implements MaterialService {

	private static final Logger logger = LoggerFactory.getLogger(MaterialServiceImpl.class);

	private final MaterialCategoryDAO materialCategoryDAO;

	@Autowired
	public MaterialServiceImpl(MaterialCategoryDAO materialCategoryDAO) {
		this.materialCategoryDAO = materialCategoryDAO;
	}

	@Override
	public MaterialCategoryBean getMaterialCategoryById(String categoryId) {
		MaterialCategoryBean materialCategoryBean = null;
		materialCategoryBean = materialCategoryDAO.findById(categoryId)
				.map(this::convertEntityToBean)
				.orElse(null);
		if (materialCategoryBean == null) {
			logger.info("Material category not found for categoryId: {}", categoryId);
		} else {
			logger.info("Material category found for categoryId: {}", categoryId);
		}
		return materialCategoryBean;
	}

	@Override
	public List<MaterialCategoryBean> getMaterialCategories() {
		List<MaterialCategoryBean> materialCategoryBeans = materialCategoryDAO.findAll().stream()
				.map(this::convertEntityToBean)
				.toList();
		if (materialCategoryBeans.isEmpty()) {
			logger.info("No material categories found.");
		}
		return materialCategoryBeans;
	}

	private final MaterialCategoryBean convertEntityToBean(MaterialCategoryEntity materialCategoryEntity) {
		MaterialCategoryBean materialCategoryBean = new MaterialCategoryBean();
		materialCategoryBean.setCategoryId(materialCategoryEntity.getCategoryId());
		materialCategoryBean.setCategoryName(materialCategoryEntity.getCategoryName());
		return materialCategoryBean;
	}

}
