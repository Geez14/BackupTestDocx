package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.business.bean.UnitBean;
import com.training.dao.UnitDAO;
import com.training.entity.UnitEntity;

@Service
public class UnitServiceImpl implements UnitService {

	private final UnitDAO unitDAO;

	@Autowired
	public UnitServiceImpl(UnitDAO unitDAO) {
		this.unitDAO = unitDAO;
	}

	public List<UnitBean> getUnitsBasedOnCategoryId(String categoryId) {
		List<UnitBean> unitBeans = null;
		List<UnitEntity> unitEntities = unitDAO.findByMaterialCategoryEntityCategoryId(categoryId);
		unitBeans = unitEntities.stream()
				.map(this::convertEntityToBean)
				.toList();
		return unitBeans;
	}

	@Override
	public List<UnitBean> getUnits() {
		List<UnitBean> unitBeans = null;
		List<UnitEntity> unitEntries = unitDAO.findAll();
		unitBeans = unitEntries.stream()
				.map(this::convertEntityToBean)
				.toList();
		return unitBeans;
	}

	private final UnitBean convertEntityToBean(UnitEntity unitEntity) {
		UnitBean unitBean = new UnitBean();
		unitBean.setUnitId(unitEntity.getUnitId());
		unitBean.setUnitName(unitEntity.getUnitName());
		unitBean.setCategoryId(unitEntity.getMaterialCategoryEntity().getCategoryId());
		return unitBean;
	}

}
