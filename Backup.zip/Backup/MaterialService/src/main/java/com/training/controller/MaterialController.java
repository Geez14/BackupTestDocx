package com.training.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.training.business.bean.MaterialCategoryBean;
import com.training.service.MaterialService;

@CrossOrigin("http://localhost:3000")
@RestController
public class MaterialController {

	private final MaterialService materialService;

	@Autowired
	public MaterialController(MaterialService materialService) {
		this.materialService = materialService;
	}

	@GetMapping(value = "/")
	public String index() {
		return "Welcome to Spring Boot Material Service API!";
	}

	@GetMapping(value = "/material/controller/getMaterialCategories", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<MaterialCategoryBean>> getMaterialCategories() {
		return ResponseEntity.ok(materialService.getMaterialCategories());
	}

	@GetMapping(value = "/material/controller/getMaterialCategoryById/{categoryId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MaterialCategoryBean> getMaterialCategoryById(@PathVariable String categoryId) {
		return ResponseEntity.of(Optional.ofNullable(materialService.getMaterialCategoryById(categoryId)));
	}

}
