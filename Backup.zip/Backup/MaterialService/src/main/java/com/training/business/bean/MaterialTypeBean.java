package com.training.business.bean;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MaterialTypeBean {

	private String typeId;

	private String typeName;

	private String categoryId;
}
