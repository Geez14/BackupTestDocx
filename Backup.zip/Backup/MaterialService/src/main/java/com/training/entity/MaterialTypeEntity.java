package com.training.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.*;

@Entity
@Table(name = "material_type")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MaterialTypeEntity {

	@Id
	@Column(name = "type_id")
	private String typeId;

	@Column(name = "type_name")
	private String typeName;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "category_id")
	private MaterialCategoryEntity materialCategoryEntity;

}
