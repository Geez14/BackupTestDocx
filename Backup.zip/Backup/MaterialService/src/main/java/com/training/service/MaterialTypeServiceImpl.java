package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.business.bean.MaterialTypeBean;
import com.training.dao.MaterialTypeDAO;
import com.training.entity.MaterialTypeEntity;

@Service
public class MaterialTypeServiceImpl implements MaterialTypeService {

	private final MaterialTypeDAO materialTypeDAO;

	@Autowired
	public MaterialTypeServiceImpl(MaterialTypeDAO materialTypeDAO) {
		this.materialTypeDAO = materialTypeDAO;
	}

	@Override
	public List<MaterialTypeBean> getMaterialTypesBasedOnCategoryId(String categoryId) {
		return materialTypeDAO.findByMaterialCategoryEntityCategoryId(categoryId).stream()
				.map(this::convertEntityToBean)
				.toList();
	}

	@Override
	public List<MaterialTypeBean> getMaterialTypes() {
		return materialTypeDAO.findAll().stream()
				.map(this::convertEntityToBean)
				.toList();
	}

	private final MaterialTypeBean convertEntityToBean(MaterialTypeEntity materialTypeEntity) {
		MaterialTypeBean materialTypeBean = new MaterialTypeBean();
		materialTypeBean.setTypeId(materialTypeEntity.getTypeId());
		materialTypeBean.setTypeName(materialTypeEntity.getTypeName());
		materialTypeBean.setCategoryId(materialTypeEntity.getMaterialCategoryEntity().getCategoryId());
		return materialTypeBean;
	}
}
