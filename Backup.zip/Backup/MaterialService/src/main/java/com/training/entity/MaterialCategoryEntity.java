package com.training.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.*;

@Entity
@Table(name = "material_category")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MaterialCategoryEntity {

	@Id
	@Column(name = "category_id")
	private String categoryId;
	@Column(name = "category_name")
	private String categoryName;
}
