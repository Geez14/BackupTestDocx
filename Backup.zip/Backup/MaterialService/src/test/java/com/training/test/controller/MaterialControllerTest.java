package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.hasSize;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.business.bean.MaterialCategoryBean;
import com.training.controller.MaterialController;
import com.training.service.MaterialService;

@WebMvcTest(MaterialController.class)
class MaterialControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private MaterialService materialServiceMock;

	@Test
	void indexMaterialControllerTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/")).andExpect(status().isOk())
				.andExpect(content().string("Welcome to Spring Boot Material Service API!"));
	}

	@Test
	void getMaterialCategoriesTest() throws Exception {

		List<MaterialCategoryBean> materialCategoryBeans = new ArrayList<>();

		MaterialCategoryBean bean = new MaterialCategoryBean("C001", "Thread");
		materialCategoryBeans.add(bean);

		bean = new MaterialCategoryBean("C002", "Cloth");
		materialCategoryBeans.add(bean);

		bean = new MaterialCategoryBean("C003", "Button");
		materialCategoryBeans.add(bean);

		when(materialServiceMock.getMaterialCategories()).thenReturn(materialCategoryBeans);

		mockMvc.perform(MockMvcRequestBuilders.get("/material/controller/getMaterialCategories"))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$", hasSize(3)))

				// check if the json node exsits
				.andExpect(jsonPath("$[0].categoryId").exists())
				.andExpect(jsonPath("$[0].categoryName").exists())

				// check the type of json node
				.andExpect(jsonPath("$[0].categoryId").isString())
				.andExpect(jsonPath("$[0].categoryName").isString())
				// check the return value
				.andExpect(jsonPath("$[0].categoryId").value("C001"))
				.andExpect(jsonPath("$[0].categoryName").value("Thread"));
	}

	@Test
	void getMaterialCategoryByIdTest() throws Exception {
		String categoryId = "C001";
		MaterialCategoryBean bean = new MaterialCategoryBean("C001", "Thread");

		when(materialServiceMock.getMaterialCategoryById(categoryId)).thenReturn(bean);

		mockMvc.perform(MockMvcRequestBuilders.get(
				"/material/controller/getMaterialCategoryById/" + categoryId))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))

				// check if the json node exsits
				.andExpect(jsonPath("$.categoryId").exists())
				.andExpect(jsonPath("$.categoryName").exists())

				// check the type of json node
				.andExpect(jsonPath("$.categoryId").isString())
				.andExpect(jsonPath("$.categoryName").isString())

				.andExpect(jsonPath("$.categoryId").value("C001"))
				.andExpect(jsonPath("$.categoryName").value("Thread"));

	}

}
