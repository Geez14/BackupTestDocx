package com.training.test.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.dao.MaterialCategoryDAO;
import com.training.entity.MaterialCategoryEntity;

@SpringBootTest
class MaterialCategoryDAOTest {

	@Autowired
	private MaterialCategoryDAO materialCategoryDAO;

	@Test
	void notNullMaterialCategoryDAOTest() {
		assertNotNull(materialCategoryDAO);
	}

	@Test
	void findByIdMaterialCategoryTest() {
		MaterialCategoryEntity entity = materialCategoryDAO.findById("C001").orElse(null);
		assertNotNull(entity);
		assertEquals("Thread", entity.getCategoryName());
	}

	@Test
	void findAllMaterialCategoryTest() {
		assertNotNull(materialCategoryDAO.findAll());
		assertEquals(4, materialCategoryDAO.findAll().size());
	}

}
