package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.service.MaterialService;

@SpringBootTest
class MaterialServiceTest {

	@Autowired
	private MaterialService materialService;

	@Test
	void notNullMaterialServiceTest() {
		assertNotNull(materialService);
	}

	@Test
	void getMaterialCategoryByIdTest() {
		assertNotNull(materialService.getMaterialCategoryById("C001"));
		assertEquals("Thread", materialService.getMaterialCategoryById("C001").getCategoryName());
	}

	@Test
	void getMaterialCategoriesTest() {
		assertNotNull(materialService.getMaterialCategories());
		assertEquals(4, materialService.getMaterialCategories().size());
	}

}
