package com.training.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialServiceApplicationTests {
	private static final Logger logger = LoggerFactory.getLogger(MaterialServiceApplicationTests.class);

	@Test
	void contextLoads() {
		logger.info("\033[32mUNIT TEST STARTED\033[0m");
		String actual = "Spring Boot";
		assertEquals("Spring Boot", actual, "Spring Boot is not equal to actual");
	}

}
