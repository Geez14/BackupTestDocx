src/
├── assets/
│   └── styles.css                 # Global styles (Tailwind or custom CSS based on your green theme)
├── components/                    # Shared, reusable UI elements
│   ├── layout/
│   │   └── Header.jsx             # The top banner ("Inventory Management System UI")
│   └── ui/
│       ├── Button.jsx             # Styled buttons (e.g., the dark green "Save Purchase" / "Get Report")
│       ├── SelectDropdown.jsx     # Reusable dropdown for Vendors, Categories, etc.
│       ├── DatePickerInput.jsx    # Date picker wrapper
│       ├── TextField.jsx          # Standard text/number inputs
│       └── TabNavigation.jsx      # The toggle buttons for switching views
├── features/                      # Complex, domain-specific modules
│   ├── PurchaseEntry/
│   │   ├── components/
│   │   │   └── PurchaseForm.jsx   # The form seen in image_7fb814.jpg
│   │   ├── hooks/
│   │   │   └── usePurchaseForm.js # Handles category->unit/type fetching and validation
│   │   └── PurchaseEntryTab.jsx   # Main container for this tab
│   └── Reports/
│       ├── components/
│       │   ├── ReportFilter.jsx   # The top filter form seen in image_7fb833.jpg
│       │   └── ReportTable.jsx    # The data table displaying the results
│       ├── hooks/
│       │   └── useReportData.js   # Handles fetching the report and managing table state
│       └── FetchReportTab.jsx     # Main container for this tab
├── services/                      # API communication layer
│   ├── apiClient.js               # Axios/Fetch base instance (baseURL: localhost:8081)
│   ├── metadataService.js         # GET categories, GET vendors
│   ├── purchaseService.js         # POST getUnitAndTypeList, POST addPurchaseDetail
│   └── reportService.js           # POST report/controller/getPurchaseDetails
├── utils/
│   ├── dateFormatters.js          # Helpers to swap between yyyy-MM-dd and dd-MM-yyyy
│   └── validationSchemas.js       # Yup/Zod schemas mapping to your backend @Valid rules
├── App.jsx                        # Root component: manages active tab state and renders the layout
└── main.jsx                       # React DOM rendering entry point