import apiClient from './apiClient';

/**
 * Fetches a list of purchase details based on a vendor and date range.
 * Note: Backend STRICTLY validates this payload. Dates must be formatted as yyyy-MM-dd.
 * 
 * @param {Object} reportBean - Matches VendorWisePurchaseReportBean { fromDate, toDate, vendorName }
 * @returns {Promise<Array>} List of PurchaseBean objects matching the criteria
 */
export const getPurchaseDetails = async (reportBean) => {
  const response = await apiClient.post('/report/controller/getPurchaseDetails', reportBean);
  return response.data;
};