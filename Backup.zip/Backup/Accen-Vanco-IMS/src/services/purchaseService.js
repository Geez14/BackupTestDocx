import apiClient from './apiClient';

/**
 * Retrieves an empty PurchaseBean template.
 * @returns {Promise<Object>} Empty PurchaseBean object
 */
export const getEmptyPurchaseEntry = async () => {
  const response = await apiClient.get('/purchaseEntry');
  return response.data;
};

/**
 * Fetches corresponding units and material types based on the selected category.
 * Note: Backend does NOT validate this payload strictly (@Valid is omitted).
 * 
 * @param {Object} partialPurchaseBean - The current state of the form
 * @returns {Promise<Object>} { unitList: [], materialTypeList: [] }
 */
export const getUnitAndTypeList = async (partialPurchaseBean) => {
  const response = await apiClient.post('/getUnitAndTypeList', partialPurchaseBean);
  return response.data;
};

/**
 * Submits the fully completed and validated purchase form.
 * Note: Backend STRICTLY validates this payload (@Valid is present).
 * 
 * @param {Object} purchaseBean - The fully populated form data
 * @returns {Promise<Object>} PurchaseResponse indicating success/failure
 */
export const addPurchaseDetail = async (purchaseBean) => {
  const response = await apiClient.post('/addPurchaseDetail', purchaseBean);
  return response.data;
};