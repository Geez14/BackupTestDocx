import apiClient from './apiClient';

/**
 * Fetches the list of all available material categories.
 * @returns {Promise<Array>} Array of category objects [{ categoryId, categoryName }]
 */
export const getCategories = async () => {
  const response = await apiClient.get('/categories');
  return response.data;
};

/**
 * Fetches the list of all available vendors.
 * @returns {Promise<Array>} Array of vendor objects
 */
export const getVendors = async () => {
  const response = await apiClient.get('/vendors');
  return response.data;
};