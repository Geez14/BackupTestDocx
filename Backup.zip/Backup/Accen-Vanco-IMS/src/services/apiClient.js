import axios from 'axios';

// Create an Axios instance with default configurations
const apiClient = axios.create({
    baseURL: 'http://localhost:8086', // Your Spring Boot backend URL
    // CRITICAL: Since your backend uses HttpSession, this ensures 
    // the JSESSIONID cookie is sent back and forth across CORS.
    // withCredentials: true,

    headers: {
        'Content-Type': 'application/json'
    },
});

// GlobalResponseHandler
apiClient.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        if (error.response) {
            console.error('API Error Response:', error.response.data);

            if (error.response.status === 401) {
                console.warn("Session expired or unauthorized.");
            }
        } else if (error.request) {
            console.error('API No Response:', error.request);
        } else {
            console.error('API Setup Error:', error.message);
        }
        return Promise.reject(error);
    }
);

export default apiClient;