import React, { useState } from 'react';
import './assets/styles.css'; // Your global stylesheet

import Header from './components/layout/Header';
import TabNavigation from './components/ui/TabNavigation';

import PurchaseEntryTab from './features/PurchaseEntry/PurchaseEntryTab';
import FetchReportTab from './features/Reports/FetchReportTab';

const App = () => {
  const [activeTab, setActiveTab] = useState('entry');

  return (
    <div className="app-container">
      <Header />
      
      <main className="main-content">
        {/* Pass the state and the updater function to the navigation */}
        <TabNavigation 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        
        {/* Conditionally render the feature modules based on state */}
        <div className="tab-content">
          {activeTab === 'entry' ? <PurchaseEntryTab /> : <FetchReportTab />}
        </div>
      </main>
    </div>
  );
};

export default App;