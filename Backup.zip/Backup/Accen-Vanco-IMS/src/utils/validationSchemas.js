import * as yup from 'yup';

// 1. Schema for /inventory/addPurchaseDetail (PurchaseBean)
export const purchaseEntrySchema = yup.object().shape({
  vendorName: yup.string().trim().required('Vendor name is mandatory.'),
  materialCategoryId: yup.string().required('Material category is mandatory.'),
  materialTypeId: yup.string().required('Material type is mandatory.'),
  brandName: yup.string().trim().required('Brand name is mandatory.'),
  unitId: yup.string().required('Unit ID is mandatory.'),
  
  // @NotNull - We also add typeError and positive() for better UX
  quantity: yup.number()
    .typeError('Quantity must be a valid number.')
    .required('Quantity is mandatory.')
    .positive('Quantity must be greater than zero.')
    .integer('Quantity must be a whole number.'),
    
  // @NotNull
  purchaseAmount: yup.number()
    .typeError('Purchase amount must be a valid number.')
    .required('Purchase amount is mandatory.')
    .positive('Purchase amount must be greater than zero.'),

  // Mirrors your @AssertTrue isPurchaseDateBeforeToday() logic
  purchaseDate: yup.date()
    .nullable()
    .required('Purchase date is mandatory.')
    .test(
      'is-before-today',
      'Purchase date must be before today.',
      function (value) {
        if (!value) return true; // Handled by .required()
        
        // Replicating your Java Calendar logic to strip the time
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        return value.getTime() < today.getTime();
      }
    ),
});


// ---------------------------------------------------------
// 2. Schema for /inventory/report/controller/getPurchaseDetails 
//    (VendorWisePurchaseReportBean)
// ---------------------------------------------------------
export const reportFilterSchema = yup.object().shape({
  vendorName: yup.string().trim().required('Vendor name is mandatory.'),
  
  fromDate: yup.date()
    .nullable()
    .required('From date is mandatory.'),
    
  toDate: yup.date()
    .nullable()
    .required('To date is mandatory.')
    // Bonus UX: Ensure 'toDate' doesn't happen before 'fromDate'
    .min(yup.ref('fromDate'), 'To date cannot be before From date.') 
});