/**
 * Formats a JavaScript Date object to "dd-MM-yyyy"
 * Expected by: PurchaseBean (POST /inventory/addPurchaseDetail)
 * 
 * @param {Date|string} dateInput - The JS Date object or ISO string from the date picker
 * @returns {string|null} Formatted string like "29-07-2026", or null if input is missing
 */
export const formatToDDMMYYYY = (dateInput) => {
  if (!dateInput) return null;

  const date = new Date(dateInput);
  if (isNaN(date.getTime())) return null; // Fallback for invalid dates

  // padStart(2, '0') ensures single digits become double digits (e.g., '7' -> '07')
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed in JS
  const year = date.getFullYear();

  return `${year}-${month}-${day}`;
};

/**
 * Formats a JavaScript Date object to "yyyy-MM-dd"
 * Expected by: VendorWisePurchaseReportBean (POST /inventory/report/controller/getPurchaseDetails)
 * 
 * @param {Date|string} dateInput - The JS Date object or ISO string from the date picker
 * @returns {string|null} Formatted string like "2026-07-29", or null if input is missing
 */
export const formatToYYYYMMDD = (dateInput) => {
  if (!dateInput) return null;

  const date = new Date(dateInput);
  if (isNaN(date.getTime())) return null;

  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${year}-${month}-${day}`;
};