const Header = () => {
    return (
        <header className="app-header">
            <h1 className="header-title">Inventory Management System UI</h1>
            <p className="header-subtitle">Spring Boot connected React frontend</p>
        </header>
    );
};
export default Header;