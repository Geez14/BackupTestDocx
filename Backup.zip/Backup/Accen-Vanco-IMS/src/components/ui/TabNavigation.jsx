import React from 'react';

const TabNavigation = ({ activeTab, onTabChange }) => {
  return (
    <div className="tab-navigation">
      <button 
        className={`tab-btn ${activeTab === 'entry' ? 'active' : ''}`}
        onClick={() => onTabChange('entry')}
      >
        Add Purchase Entry
      </button>
      <button 
        className={`tab-btn ${activeTab === 'report' ? 'active' : ''}`}
        onClick={() => onTabChange('report')}
      >
        Fetch Report
      </button>
    </div>
  );
};

export default TabNavigation;