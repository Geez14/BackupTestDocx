import React, { forwardRef } from 'react';

const SelectDropdown = forwardRef(({ label, id, error, options = [], placeholder = 'Select...', ...rest }, ref) => {
  return (
    <div className="input-group">
      {label && <label htmlFor={id} className="input-label">{label}</label>}
      <select
        id={id}
        ref={ref}
        className={`standard-input ${error ? 'input-error' : ''}`}
        defaultValue="" /* Ensures the placeholder shows by default */
        {...rest}
      >
        <option value="" disabled>
          {placeholder}
        </option>
        
        {/* Safely map over the options array to generate dropdown items */}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      
      {error && <span className="error-text">{error.message}</span>}
    </div>
  );
});

SelectDropdown.displayName = 'SelectDropdown';

export default SelectDropdown;