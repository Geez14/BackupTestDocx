import React, { useEffect } from 'react';

const Popup = ({ message, isError = false, onClose }) => {
  // Auto-dismiss after 3 seconds
  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    
    return () => clearTimeout(timer); // Cleanup if component unmounts early
  }, [message, onClose]);

  if (!message) return null;

  return (
    <div className={`custom-popup ${isError ? 'popup-error' : 'popup-success'}`}>
      <span className="popup-message">{message}</span>
      <button className="popup-close" onClick={onClose}>&times;</button>
    </div>
  );
};

export default Popup;