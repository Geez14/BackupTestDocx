import React, { forwardRef } from 'react';

const TextField = forwardRef(({ label, id, error, type = 'text', ...rest }, ref) => {
  return (
    <div className="input-group">
      {label && <label htmlFor={id} className="input-label">{label}</label>}
      <input
        id={id}
        type={type}
        ref={ref}
        className={`standard-input ${error ? 'input-error' : ''}`}
        {...rest}
      />
      {error && <span className="error-text">{error.message}</span>}
    </div>
  );
});

// Setting displayName is a React best practice when using forwardRef
TextField.displayName = 'TextField'; 

export default TextField;