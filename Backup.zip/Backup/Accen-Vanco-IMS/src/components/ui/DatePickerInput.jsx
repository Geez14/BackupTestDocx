import React, { forwardRef } from 'react';

const DatePickerInput = forwardRef(({ label, id, error, ...rest }, ref) => {
  return (
    <div className="input-group">
      {label && <label htmlFor={id} className="input-label">{label}</label>}
      <input
        id={id}
        type="date"
        ref={ref}
        className={`standard-input date-input ${error ? 'input-error' : ''}`}
        {...rest}
      />
      {error && <span className="error-text">{error.message}</span>}
    </div>
  );
});

DatePickerInput.displayName = 'DatePickerInput';

export default DatePickerInput;