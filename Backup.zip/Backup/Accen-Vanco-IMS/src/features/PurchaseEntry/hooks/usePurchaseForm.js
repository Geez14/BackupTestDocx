import { useState, useEffect } from 'react';
import { getCategories, getVendors } from '../../../services/metadataService';
import { getUnitAndTypeList, addPurchaseDetail } from '../../../services/purchaseService';

export const usePurchaseForm = (formData) => {
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [materialTypes, setMaterialTypes] = useState([]);
  const [units, setUnits] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [popup, setPopup] = useState(null);

  // 1. Fetch initial Vendors and Categories on load
  useEffect(() => {
    const fetchInitialData = async () => {
      setPopup(null);
      try {
        const [vendorData, categoryData] = await Promise.all([
          getVendors(),
          getCategories()
        ]);
        setVendors(vendorData.map(v => ({ label: v.vendorName, value: v.vendorName })));
        setCategories(categoryData.map(c => ({ label: c.categoryName, value: c.categoryId })));
      } catch (error) {
        setPopup({ message: `Failed to fetch Categories and Vendors: ${error.message}`, isError: true });
      }
    };
    fetchInitialData();
  }, []);

  // 2. Fetch dependent Dropdowns when Category changes
  useEffect(() => {
    const fetchDependentData = async () => {
      if (!formData.materialCategoryId) {
        setMaterialTypes([]);
        setUnits([]);
        return;
      }
      setPopup(null);

      try {
        const response = await getUnitAndTypeList(formData);
        setUnits(response.unitList.map(u => ({ label: u.unitName, value: u.unitId })));
        setMaterialTypes(response.materialTypeList.map(t => ({ label: t.typeName, value: t.typeId })));
      } catch (error) {

        setPopup({ message: `Failed to load categories: ${error.message}`, isError: true });
      }
    };

    fetchDependentData();
  }, [formData, formData.materialCategoryId]);

  // 3. Handle Form Submission
  const submitPurchase = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setPopup(null);

    try {
      // Find the selected items to extract their labels (names)
      const selectedCategory = categories.find(c => c.value === formData.materialCategoryId);
      const selectedType = materialTypes.find(t => t.value === formData.materialTypeId);
      const selectedUnit = units.find(u => u.value === formData.unitId);

      // Construct the complete payload matching the Java Bean requirements
      const payload = {
        vendorName: formData.vendorName,
        materialCategoryId: formData.materialCategoryId,
        materialTypeId: formData.materialTypeId,
        brandName: formData.brandName,
        unitId: formData.unitId,
        quantity: Number(formData.quantity),
        purchaseAmount: Number(formData.purchaseAmount),
        balance: Number(formData.purchaseAmount),
        purchaseDate: new Date(`${formData.purchaseDate}T00:00:00`).toISOString(),
        materialCategoryName: selectedCategory?.label || "",
        materialTypeName: selectedType?.label || "",
        materialUnitName: selectedUnit?.label || "",
        status: "PENDING",
      };

      await addPurchaseDetail(payload);
      setPopup({ message: 'Purchase Entry Saved Successfully!', isError: false });
    } catch (error) {
      setPopup({ message: `Failed to save purchase entry ${error.message}`, isError: true });
    } finally {
      setIsSubmitting(false);
    }
  };

  return { vendors, categories, materialTypes, units, isSubmitting, submitPurchase, popup, clearPopup: () => setPopup(null) };
};