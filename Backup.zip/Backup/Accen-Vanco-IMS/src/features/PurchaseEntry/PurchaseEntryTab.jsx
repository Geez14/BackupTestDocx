import React from 'react';
import PurchaseForm from './components/PurchaseForm';
const PurchaseEntryTab = () => {
    return (
        <div className="tab-pane">
            <h2 style={{ color: '#0f766e', marginBottom: '1.5rem', padding: '0 2rem' }}>
                Add Purchase Entry
            </h2>
            <PurchaseForm />
        </div>
    );
};

export default PurchaseEntryTab;