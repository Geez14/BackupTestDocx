import React, { useState } from 'react';
import { usePurchaseForm } from '../hooks/usePurchaseForm';

import TextField from '../../../components/ui/TextField';
import Popup from '../../../components/ui/Popup';
import SelectDropdown from '../../../components/ui/SelectDropdown';
import DatePickerInput from '../../../components/ui/DatePickerInput';
import Button from '../../../components/ui/Button';

const PurchaseForm = () => {
  const [formData, setFormData] = useState({
    vendorName: '',
    materialCategoryId: '',
    materialTypeId: '',
    brandName: '',
    unitId: '',
    quantity: '',
    purchaseAmount: '',
    purchaseDate: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
  };

  const { vendors, categories, materialTypes, units, isSubmitting, submitPurchase, popup, clearPopup } = 
    usePurchaseForm(formData);

  return (
    <form onSubmit={submitPurchase} className="form-container">
      <Popup 
        message={popup?.message} 
        isError={popup?.isError} 
        onClose={clearPopup}
      />

      <div className="form-grid">
        <SelectDropdown
          label="Vendor Name"
          id="vendorName"
          placeholder="Select vendor"
          options={vendors}
          value={formData.vendorName}
          onChange={handleChange}
          required
        />

        <SelectDropdown
          label="Material Category"
          id="materialCategoryId"
          placeholder="Select category"
          options={categories}
          value={formData.materialCategoryId}
          onChange={handleChange}
          required
        />

        <SelectDropdown
          label="Material Type"
          id="materialTypeId"
          placeholder="Select material type"
          options={materialTypes}
          disabled={!formData.materialCategoryId} 
          value={formData.materialTypeId}
          onChange={handleChange}
          required
        />

        <TextField
          label="Brand Name"
          id="brandName"
          value={formData.brandName}
          onChange={handleChange}
          required
        />

        <SelectDropdown
          label="Unit"
          id="unitId"
          placeholder="Select unit"
          options={units}
          disabled={!formData.materialCategoryId}
          value={formData.unitId}
          onChange={handleChange}
          required
        />

        <TextField
          label="Quantity"
          id="quantity"
          type="number"
          min="1"
          value={formData.quantity}
          onChange={handleChange}
          required
        />

        <TextField
          label="Purchase Amount"
          id="purchaseAmount"
          type="number"
          step="0.01"
          min="0.01"
          value={formData.purchaseAmount}
          onChange={handleChange}
          required
        />

        <DatePickerInput
          label="Purchase Date"
          id="purchaseDate"
          value={formData.purchaseDate}
          onChange={handleChange}
          required
        />
      </div>

      <div className="form-actions">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : 'Save Purchase'}
        </Button>
      </div>
    </form>
  );
};

export default PurchaseForm;