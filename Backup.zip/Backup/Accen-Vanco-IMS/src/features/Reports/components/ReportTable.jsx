import React from 'react';

const ReportTable = ({ data }) => {
  return (
    <div className="table-wrapper">
      <table className="report-table">
        <thead>
          <tr>
            <th>Purchase Id</th>
            <th>Transaction Id</th>
            <th>Vendor</th>
            <th>Category</th>
            <th>Type</th>
            <th>Brand</th>
            <th>Unit</th>
            <th>Quantity</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan="11" className="empty-state">
                No records found
              </td>
            </tr>
          ) : (
            data.map((row, index) => (
              <tr key={row.purchaseId || index}>
                <td>{row.purchaseId}</td>
                <td>{row.transactionId}</td>
                <td>{row.vendorName}</td>
                <td>{row.materialCategoryName}</td>
                <td>{row.materialTypeName}</td>
                <td>{row.brandName}</td>
                <td>{row.materialUnitName}</td>
                <td>{row.quantity}</td>
                <td>{row.purchaseAmount}</td>
                {/* Optional: You can re-format the date back to dd-MM-yyyy for display if desired */}
                <td>{row.purchaseDate}</td>
                <td>{row.status}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ReportTable;