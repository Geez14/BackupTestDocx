import React, { useState } from 'react';
import SelectDropdown from '../../../components/ui/SelectDropdown';
import DatePickerInput from '../../../components/ui/DatePickerInput';
import Button from '../../../components/ui/Button';

const ReportFilter = ({ vendors, isLoading, onFetchReport }) => {
  const [filterData, setFilterData] = useState({
    vendorName: '',
    fromDate: '',
    toDate: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFilterData((prev) => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onFetchReport(filterData);
  };

  return (
    <form onSubmit={handleSubmit} className="report-filter-container">
      <div className="form-grid">
        <SelectDropdown
          label="Vendor Name"
          id="vendorName"
          placeholder="Select vendor"
          options={vendors}
          value={filterData.vendorName}
          onChange={handleChange}
          required
        />

        <DatePickerInput
          label="From Date"
          id="fromDate"
          value={filterData.fromDate}
          onChange={handleChange}
          required
        />

        <DatePickerInput
          label="To Date"
          id="toDate"
          value={filterData.toDate}
          onChange={handleChange}
          required
        />
      </div>

      <div className="filter-actions">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Fetching...' : 'Get Report'}
        </Button>
      </div>
    </form>
  );
};

export default ReportFilter;