import { useState, useEffect } from 'react';
import { getVendors } from '../../../services/metadataService';
import { getPurchaseDetails } from '../../../services/reportService';
import { formatToYYYYMMDD } from '../../../utils/dateFormatters';

export const useReportData = () => {
  const [vendors, setVendors] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [popup, setPopup] = useState(null);

  // Fetch vendors on load to populate the dropdown
  useEffect(() => {
    const fetchInitialData = async () => {
      setPopup(null);
      try {
        const vendorData = await getVendors();
        setVendors(vendorData.map(v => ({ label: v.vendorName, value: v.vendorName })));
      } catch (error) {
        setPopup({ message: `Failed to load vendors: ${error.message}`, isError: true });
      }
    };
    fetchInitialData();
  }, []);

  // Handle the report fetching
  const fetchReport = async (filterData) => {
    setIsLoading(true);
    try {
      const payload = {
        vendorName: filterData.vendorName,
        fromDate: formatToYYYYMMDD(filterData.fromDate),
        toDate: formatToYYYYMMDD(filterData.toDate)
      };

      const data = await getPurchaseDetails(payload);
      setReportData(data || []); // Ensure we always have an array
    } catch (error) {
      console.error("Failed to fetch report details", error);
      setPopup({ message: `Failed to fetch report details: ${error.message}`, isError: true });
    } finally {
      setIsLoading(false);
    }
  };

  return { vendors, reportData, isLoading, fetchReport, popup, clearPopup: () => setPopup(null) };
};