import React from 'react';
import { useReportData } from './hooks/useReportData';
import ReportFilter from './components/ReportFilter';
import ReportTable from './components/ReportTable';
import Popup from '../../components/ui/Popup';

const FetchReportTab = () => {
  const { vendors, reportData, isLoading, fetchReport, popup, clearPopup } = useReportData();

  return (
    <div className="tab-pane">
      <h2 style={{ color: '#0f766e', marginBottom: '1.5rem', padding: '0 2rem' }}>
        Fetch Report
      </h2>
      <Popup 
        message={popup?.message} 
        isError={popup?.isError} 
        onClose={clearPopup}
      />
      <ReportFilter 
        vendors={vendors} 
        isLoading={isLoading} 
        onFetchReport={fetchReport} 
      />
      <ReportTable data={reportData} />
    </div>
  );
};

export default FetchReportTab;